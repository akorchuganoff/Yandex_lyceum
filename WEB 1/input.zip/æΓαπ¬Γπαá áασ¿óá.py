from zipfile import ZipFile

with ZipFile('input.zip') as myzip:
    info = myzip.infolist()
    print(info)